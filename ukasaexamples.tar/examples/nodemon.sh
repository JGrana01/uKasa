#!/bin/sh

# nodemon - make sure an AiMesh node is on-line.
#
# if a node (or any network device plugged into a Kasa plug) doesn't respond
#  power cycle it - and hope for the best ;-)
#
# I would invoke this from cron, running something like every 15 mins by adding
# this line to services-start (changing the IP address to the nodes)
#
#   cru a NodeMon "*/15 * * * * sh /jffs/scripts/nodemon.sh 192.168.1.7"

if ! ping -q -c 2 -W 2 $1 >/dev/null; then
	/jffs/scripts/ukasa $1 off
	sleep 5
	/jffs/scripts/ukasa $1 on
	logger -t "nodemon" "Power cycled Node $1"

# ideally send an email when cycled

	echo "Node $1 was power cycled" > /tmp/mail1.txt
	date >> /tmp/mail1.txt
	echo >> /tmp/mail1.txt
#
# insert favorite method to send an email here
#

fi


